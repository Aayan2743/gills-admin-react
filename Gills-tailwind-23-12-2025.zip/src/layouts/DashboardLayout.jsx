// import { useState } from "react";
// import { useAuth } from "../auth/AuthContext";
// import { Link, useLocation } from "react-router-dom";
// import { Outlet } from "react-router-dom";

// export default function DashboardLayout({ children }) {
//   const { user, logout } = useAuth();
//   const location = useLocation();

//   const [clientOpen, setClientOpen] = useState(
//     location.pathname.startsWith("/add-client") ||
//       location.pathname.startsWith("/view-client")
//   );

//   const [confirmationOpen, setConfirmationOpen] = useState(
//     location.pathname.startsWith("/confirmation") ||
//       location.pathname.startsWith("/confirmation-list")
//   );

//   const [open, setOpen] = useState(false);
//   const [profileOpen, setProfileOpen] = useState(false);

//   const isActive = (path) =>
//     location.pathname === path
//       ? "bg-indigo-100 text-indigo-600 font-semibold"
//       : "text-gray-700 hover:bg-indigo-50";

//   const pageTitle =
//     location.pathname.replace("/", "").toUpperCase() || "DASHBOARD";

//   return (
//     <div className="min-h-screen flex bg-gray-100">
//       {/* ================= SIDEBAR ================= */}

//       <div className="hidden md:block pointer-events-none" />

//       <aside
//         className={`fixed inset-y-0 left-0 z-40 w-64 bg-white shadow-xl transform
//         ${open ? "translate-x-0" : "-translate-x-full"}
//         md:translate-x-0 transition-transform duration-300 ease-in-out`}
//       >
//         <div className="h-full flex flex-col">
//           <div className="p-6 border-b">
//             <h1 className="text-2xl font-bold text-indigo-600">Gills Lab</h1>
//             <p className="text-sm text-gray-500 capitalize">{user.role}</p>
//           </div>

//           <nav className="flex-1 p-4 space-y-1">
//             {/* Dashboard */}
//             <Link
//               to="/dashboard"
//               onClick={() => setOpen(false)}
//               className={`block px-4 py-2 rounded-lg ${isActive("/dashboard")}`}
//             >
//               📊 Dashboard
//             </Link>
//             {/* CLIENT MAIN MENU */}
//             <button
//               onClick={() => setClientOpen(!clientOpen)}
//               className="w-full flex items-center justify-between px-4 py-2 rounded-lg text-gray-700 hover:bg-indigo-50"
//             >
//               <span className="flex items-center gap-2">📁 Client</span>
//               <span className="text-sm">{clientOpen ? "▾" : "▸"}</span>
//             </button>
//             {/* CLIENT SUB MENU */}
//             {clientOpen && (
//               <div className="ml-6 space-y-1">
//                 <Link
//                   to="/add-client"
//                   onClick={() => setOpen(false)}
//                   className={`block px-3 py-2 rounded-lg text-sm ${isActive(
//                     "/add-client"
//                   )}`}
//                 >
//                   ➕ Add Client
//                 </Link>

//                 <Link
//                   to="/view-client"
//                   onClick={() => setOpen(false)}
//                   className={`block px-3 py-2 rounded-lg text-sm ${isActive(
//                     "/view-client"
//                   )}`}
//                 >
//                   👁 View Client
//                 </Link>
//               </div>
//             )}
//             {/* CONFITMATION MAIN MENU */}
//             <button
//               onClick={() => setConfirmationOpen(!confirmationOpen)}
//               className="w-full flex items-center justify-between px-4 py-2 rounded-lg text-gray-700 hover:bg-indigo-50"
//             >
//               <span className="flex items-center gap-2">📁 Confirmation</span>
//               <span className="text-sm">{setConfirmationOpen ? "▾" : "▸"}</span>
//             </button>
//             {/* CONFITMATION SUB MENU */}
//             {confirmationOpen && (
//               <div className="ml-6 space-y-1">
//                 <Link
//                   to="/confirmation"
//                   onClick={() => setOpen(false)}
//                   className={`block px-3 py-2 rounded-lg text-sm ${isActive(
//                     "/confirmation"
//                   )}`}
//                 >
//                   ➕ Confirmation Entry
//                 </Link>

//                 <Link
//                   to="/confirmation-list"
//                   onClick={() => setOpen(false)}
//                   className={`block px-3 py-2 rounded-lg text-sm ${isActive(
//                     "/confirmation-list"
//                   )}`}
//                 >
//                   👁 Confirmation List
//                 </Link>
//               </div>
//             )}
//             {/* Invoice Cash Memo */}
//             <Link
//               to="/invoice-cash-memo-list"
//               onClick={() => setOpen(false)}
//               className={`block px-4 py-2 rounded-lg ${isActive(
//                 "/invoice-cash-memo-list"
//               )}`}
//             >
//               💰 Invoice & Cash Memo
//             </Link>
//           </nav>

//           <div className="p-4 border-t">
//             <button
//               onClick={logout}
//               className="w-full bg-red-500 text-white py-2 rounded-lg hover:bg-red-600 transition"
//             >
//               Logout
//             </button>
//           </div>
//         </div>
//       </aside>

//       {/* ================= OVERLAY ================= */}
//       {open && (
//         <div
//           onClick={() => setOpen(false)}
//           className="fixed inset-0 bg-black/40 z-30 md:hidden"
//         />
//       )}

//       {/* ================= MAIN ================= */}
//       <div className="flex-1 flex flex-col md:ml-64">
//         {/* TOP BAR */}
//         <header className="bg-white shadow-sm px-6 py-4 flex items-center justify-between">
//           <button
//             onClick={() => setOpen(true)}
//             className="md:hidden text-gray-600 text-2xl"
//           >
//             ☰
//           </button>

//           <h2 className="text-lg font-semibold text-gray-800">{pageTitle}</h2>

//           {/* PROFILE */}
//           <div className="relative">
//             <button
//               onClick={() => setProfileOpen(!profileOpen)}
//               className="flex items-center gap-2"
//             >
//               <div className="w-9 h-9 rounded-full bg-indigo-600 text-white flex items-center justify-center font-semibold">
//                 {user.name?.charAt(0).toUpperCase()}
//               </div>
//               <span className="hidden md:block text-sm text-gray-700">
//                 {user.name}
//               </span>
//               <span className="text-gray-500">▾</span>
//             </button>

//             {profileOpen && (
//               <>
//                 <div
//                   className="fixed inset-0 z-30"
//                   onClick={() => setProfileOpen(false)}
//                 />
//                 <div className="absolute right-0 mt-3 w-48 bg-white border rounded-lg shadow-lg z-40">
//                   <div className="px-4 py-2 text-sm text-gray-500 border-b">
//                     {user.email}
//                   </div>
//                   <button className="w-full text-left px-4 py-2 hover:bg-gray-100">
//                     Profile
//                   </button>
//                   <button className="w-full text-left px-4 py-2 hover:bg-gray-100">
//                     Settings
//                   </button>
//                   <button
//                     onClick={logout}
//                     className="w-full text-left px-4 py-2 text-red-600 hover:bg-red-50"
//                   >
//                     Logout
//                   </button>
//                 </div>
//               </>
//             )}
//           </div>
//         </header>

//         {/* CONTENT */}
//         {/* <main className="flex-1 p-6">{children}</main> */}
//         <main className="flex-1 p-6">
//           <Outlet />
//         </main>

//         {/* ================= FOOTER ================= */}
//         <footer className="bg-white border-t px-6 py-3 text-sm text-gray-500 flex flex-col md:flex-row items-center justify-between">
//           <span>
//             © {new Date().getFullYear()} <strong>Gills Lab</strong>. All rights
//             reserved.
//           </span>

//           <div className="flex gap-4 mt-2 md:mt-0">
//             <span className="cursor-pointer hover:text-indigo-600">
//               Privacy Policy
//             </span>
//             <span className="cursor-pointer hover:text-indigo-600">Terms</span>
//           </div>
//         </footer>
//       </div>
//     </div>
//   );
// }



import { useState } from "react";
import { Outlet, useLocation } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";
import Sidebar from "./Sidebar";

export default function DashboardLayout() {
  const { user, logout } = useAuth();
  const location = useLocation();

  const [open, setOpen] = useState(false);

  const [dataSettingsOpen, setDataSettingsOpen] = useState(
  location.pathname.startsWith("/rate-card") ||
    location.pathname.startsWith("/clarity") ||
    location.pathname.startsWith("/items")
);


  const [clientOpen, setClientOpen] = useState(
    location.pathname.startsWith("/add-client") ||
      location.pathname.startsWith("/view-client")
  );

  const [confirmationOpen, setConfirmationOpen] = useState(
    location.pathname.startsWith("/confirmation")
  );

  const pageTitle =
    location.pathname.replace("/", "").toUpperCase() || "DASHBOARD";

  return (
    <div className="min-h-screen flex bg-gray-100">
      {/* SIDEBAR */}
        <Sidebar
          open={open}
          setOpen={setOpen}
          user={user}
          logout={logout}
          clientOpen={clientOpen}
          setClientOpen={setClientOpen}
          confirmationOpen={confirmationOpen}
          setConfirmationOpen={setConfirmationOpen}
          dataSettingsOpen={dataSettingsOpen}
          setDataSettingsOpen={setDataSettingsOpen}
        />


      {/* OVERLAY */}
      {open && (
        <div
          className="fixed inset-0 bg-black/40 z-30 md:hidden"
          onClick={() => setOpen(false)}
        />
      )}

      {/* MAIN */}
      <div className="flex-1 flex flex-col md:ml-64">
        {/* HEADER */}
        <header className="bg-white shadow px-6 py-4 flex justify-between">
          <button
            className="md:hidden text-2xl"
            onClick={() => setOpen(true)}
          >
            ☰
          </button>

          <h2 className="font-semibold">{pageTitle}</h2>

          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-full bg-indigo-600 text-white flex items-center justify-center">
              {user.name?.charAt(0)}
            </div>
            <span className="hidden md:block">{user.name}</span>
          </div>
        </header>

        <main className="flex-1 p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
